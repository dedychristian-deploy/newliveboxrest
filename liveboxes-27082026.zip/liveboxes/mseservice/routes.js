const express = require("express");
const mse = require("./mse");

const router = express.Router();

router.get("/playlists", async (req, res) => {
    try {
        const response = await mse.getPlaylists(req.query.studio);

        res
            .status(response.statusCode)
            .type("application/atom+xml")
            .send(response.body);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.get("/playlist-status", async (req, res) => {
    try {
        const response = await mse.getPlaylistActivation(req.query.studio);

        const active =
            response.statusCode >= 200 &&
            response.statusCode < 300 &&
            response.body.includes("active_on_profile");

        res.json({
            active,
            playlistId: response.playlistId
        });

    } catch (err) {
        res.status(500).json({
            active: false
        });
    }
});

router.get("/elements", async (req, res) => {
    try {
        const response = await mse.getElements(req.query.path, req.query.studio);

        res
            .status(response.statusCode)
            .type("application/atom+xml")
            .send(response.body);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.get("/element", async (req, res) => {
    try {
        const response = await mse.getElement(req.query.url);

        res
            .status(response.statusCode)
            .type("application/vnd.vizrt.payload+xml")
            .send(response.body);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.put("/activate/:uuid", async (req, res) => {
    try {
        const response = await mse.activatePlaylist(req.params.uuid, req.query.studio);

        res
            .status(response.statusCode)
            .type("text/plain")
            .send(response.body);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.post("/cleanup/:uuid", async (req, res) => {
    try {
        const response = await mse.cleanupPlaylist(req.params.uuid, req.query.studio);

        res
            .status(response.statusCode)
            .type("text/plain")
            .send(response.body);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.post("/take", async (req, res) => {
    try {
        const response = await mse.takeElement(req.body, req.query.studio);

        res
            .status(response.statusCode)
            .type("text/plain")
            .send(response.body);

    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.post("/out", async (req, res) => {
    try {
        const response = await mse.takeOutElement(req.body, req.query.studio);

        res
            .status(response.statusCode)
            .type("text/plain")
            .send(response.body);

    } catch (err) {
        res.status(500).send(err.message);
    }
});


router.post("/director-reset", async (req, res) => {
    try {
        const [source, boxTypeRaw] = req.body.trim().split("|");
        const boxType = parseInt(boxTypeRaw, 10);

        console.log("DIRECTOR RESET:");
        console.log("source  =", source);
        console.log("boxType =", boxType);

        // FILTER
        if (source !== "director") {
            console.log("DIRECTOR RESET IGNORED:", source);

            return res.json({
                ok: false,
                ignored: true,
                source
            });
        }

        if (Number.isNaN(boxType)) {
            return res.status(400).json({
                ok: false,
                error: "Invalid boxType"
            });
        }

        const resetCommand =
            `-1 MAIN_SCENE*TREE*$SCRIPT*SCRIPT INVOKE msg_director_take ${boxType}`;

        console.log("DIRECTOR RESET COMMAND:", resetCommand);

        // Loopback call to this same process (127.0.0.1:9191 = this server's own
        // port, always local — that part is fine as-is). What must NOT be
        // hardcoded is which Engine the command goes to: pass studio through so
        // /vizsend resolves that studio's own engine.host/port from its config
        // instead of a fixed Engine host/port. (The old host=/port= query params
        // here were never actually read by /vizsend, so dropping them changes
        // nothing behaviorally.)
        const studio = req.query.studio;
        const studioQuery = studio ? `&studio=${encodeURIComponent(studio)}` : "";

        await fetch(
            `http://127.0.0.1:9091/vizsend?cmd=${encodeURIComponent(resetCommand)}${studioQuery}`
        );

        res.json({
            ok: true,
            source,
            boxType
        });

    } catch (err) {
        console.error("DIRECTOR RESET ERROR:", err);

        res.status(500).json({
            ok: false,
            error: err.message
        });
    }
});

module.exports = router;